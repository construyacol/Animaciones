A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/YQLppy.

 Sin utilizar ningún plugin, solo con HTML, CSS y Jquery